/*
 * custom_sense_adc_values.h
 *
 *  Created on: 15-Nov-2025
 *      Author: Harikrishnan S
 */

#include "F28x_Project.h"

#ifndef CUSTOM_SENSE_ADC_VALUES_H_
#define CUSTOM_SENSE_ADC_VALUES_H_


extern float sensor_1_slope,sensor_2_slope,sensor_1_c,sensor_2_c; // from calibration experiment
extern float adc_multiplier; // 3/4095
extern float calibration,ia_correction,ib_correction;

extern void current_sense(Uint16 adc_1,Uint16 adc_2); // function to sense current
extern void current_calibrate(Uint16 adc_1,Uint16 adc_2); // calibrate current

#endif /* CUSTOM_SENSE_ADC_VALUES_H_ */
