/*
 * custom_dac.h
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_DAC_H_
#define CUSTOM_INCLUDE_CUSTOM_DAC_H_

#include "F28x_Project.h"


extern unsigned int PWM_DAC_PRD;
extern float PWMdac1temp, PWMdac2temp, PWMdac3temp, PWMdac4temp;

extern void config_DAC(void);
extern void config_PWM_DAC(void);
extern void Update_PWM_DAC(float PWMDAC1,float PWMDAC2,float PWMDAC3,float PWMDAC4);

#endif /* CUSTOM_INCLUDE_CUSTOM_DAC_H_ */
