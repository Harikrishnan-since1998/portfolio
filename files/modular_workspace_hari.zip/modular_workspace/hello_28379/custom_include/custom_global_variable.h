/*
 * custom_global_variable.h
 *
 *  Created on: 10-Dec-2025
 *      Author: MC LAB
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_GLOBAL_VARIABLE_H_
#define CUSTOM_INCLUDE_CUSTOM_GLOBAL_VARIABLE_H_

extern float Ts;
extern float Ia,Ib,Ic;                                         // variables for sensing current
extern float Ia_filtered,Ib_filtered,Ic_filtered;              // variables for filtered current
extern int enable_protection;                                  // variable to enable protection.

extern float I_alpha,I_beta,I_d,I_q,m_alpha,m_beta,mu,mv,mw;    // variables for transformation
extern float cos_rho_trans,sin_rho_trans;                       // theta estimates
extern float m_d,m_q;                                           // controller outputs

/* =======================
 * Speed Loop
 * ======================= */
extern float speed_ref;
extern float speed_error, speed_measured, speed_prop;
extern float KP_speed, KI_speed;
extern float speed_error_prev, cont_integ_temp, speed_integ;
extern float Iq_ref, iq_limit_pos, iq_limit_neg;
extern int   iq_integ_enable;
extern int speed_integ_enable;

/* =======================
 * Iq Current Loop
 * ======================= */
extern float Iq_error, iq_prop;
extern float KP_i, KI_i;
extern float Iq_error_prev, iq_integ;
extern float mq_limit_pos, mq_limit_neg;

/* =======================
 * Id Current Loop
 * ======================= */
extern int   id_integ_enable;
extern float Id_error, Id_ref, id_prop;
extern float KP_i_d, KI_i_d;
extern float Id_error_prev, id_integ;
extern float md_limit_pos, md_limit_neg;

/* =======================
 * Feedforward + DC Link
 * ======================= */
extern float FF_Id, FF_Iq;
extern float measured_dc_voltage;

/* =======================
 * Flux Observer / Speed Estimation
 * ======================= */
extern float sa, sb, sa_previous, sb_previous;
extern float Rs, k, kk;
extern float psi_r_alpha_e, psi_r_beta_e;
extern float psi_sa, psi_sb, psi_sa_pre, psi_sb_pre;
extern float tempa, tempb;
extern float psi_s, psi_r_alpha, psi_r_beta, psi_r;
extern float psi_f, Ld, Lq, Kb;
extern float sin_rho, cos_rho, sin_rho_n1, cos_rho_n1;
extern float ws1, w, w_filtered;

/* =======================
 * Voltage Compensator
 * ======================= */
extern float Vza, Vzb, Vza_pre, Vzb_pre;
extern float Vcompa, Vcompa_pre, Vcompb, Vcompb_pre;

/* =======================
 * Active Flux Terms
 * ======================= */
extern float psi_active_a, psi_active_b;
extern float psi_active_a_CM, psi_active_b_CM;
extern float active_psi_error_a, active_psi_error_b;
extern float active_psi_error_a_pre, active_psi_error_b_pre;
extern float psi_active;

/* =======================
 * Integrators / Controllers
 * ======================= */
extern float Int_a, Int_a_pre;
extern float Int_b, Int_b_pre;
extern float Ki_comp, Kp_comp;

/* =======================
 * ESO (Extended State Observer)
 * ======================= */
extern float constantt, b1, b2;
extern float e_a, e_aprev, e_b, e_bprev;
extern float z1_a, z1_aprev, z2_a, z2_aprev;
extern float z1_b, z1_bprev, z2_b, z2_bprev;

extern float start_control;
extern float estimate;




#define PI 3.141592


#endif /* CUSTOM_INCLUDE_CUSTOM_GLOBAL_VARIABLE_H_ */
