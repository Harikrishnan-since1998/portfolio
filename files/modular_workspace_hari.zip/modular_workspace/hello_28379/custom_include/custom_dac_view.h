/*
 * custom_dac_view.h
 *
 *  Created on: 11-Dec-2025
 *      Author: MC LAB
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_DAC_VIEW_H_
#define CUSTOM_INCLUDE_CUSTOM_DAC_VIEW_H_

extern void dac_view(void);
extern float mode;

#endif /* CUSTOM_INCLUDE_CUSTOM_DAC_VIEW_H_ */
