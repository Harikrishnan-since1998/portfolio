/*
 * custom_filters.h
 *
 *  Created on: 10-Dec-2025
 *      Author: MC LAB
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_FILTERS_H_
#define CUSTOM_INCLUDE_CUSTOM_FILTERS_H_

extern float alpha_I_u;
extern float x_I_u,xprev_I_u,y_I_u,yprev_I_u;
extern float alpha_I_w ;
extern float x_I_w,xprev_I_w,y_I_w,yprev_I_w;
extern float alpha_I_v ;
extern float x_I_v,xprev_I_v,y_I_v,yprev_I_v;
extern float alpha ;
extern float x,xprev,y,yprev;



extern float first_order_filter_I_u(float x,float cutoff);
extern float first_order_filter_I_w(float x,float cutoff);
extern float first_order_filter_I_v(float x,float cutoff);
extern float first_order_filter_w(float x,float cutoff);


#endif /* CUSTOM_INCLUDE_CUSTOM_FILTERS_H_ */
