/*
 * custom_epwm.h
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_EPWM_H_
#define CUSTOM_INCLUDE_CUSTOM_EPWM_H_

#include "F28x_Project.h"
#include "math.h"

#include "custom_epwm2_isr.h"

extern unsigned int PWM_tbprd; // frequency of PWM

extern void config_EPwm(void);
extern void update_pwm(float mu,float mv,float mw);

#endif /* CUSTOM_INCLUDE_CUSTOM_EPWM_H_ */
