/*
 * custom_controller.h
 *
 *  Created on: 11-Dec-2025
 *      Author: MC LAB
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_CONTROLLER_H_
#define CUSTOM_INCLUDE_CUSTOM_CONTROLLER_H_

extern void Speed_Controller(void);
extern void FOC_Control(void);
extern void initialize_variables(void);

#endif /* CUSTOM_INCLUDE_CUSTOM_CONTROLLER_H_ */
