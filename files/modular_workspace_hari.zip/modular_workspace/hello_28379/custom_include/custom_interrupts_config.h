/*
 * custom_interrupts_config.h
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_INTERRUPTS_CONFIG_H_
#define CUSTOM_INCLUDE_CUSTOM_INTERRUPTS_CONFIG_H_

#include "F28x_Project.h"

#include "custom_adc.h"
#include "custom_epwm2_isr.h"

extern void config_interrupts(void);


#endif /* CUSTOM_INCLUDE_CUSTOM_INTERRUPTS_CONFIG_H_ */
