/*
 * custom_epwm2_isr.h
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_EPWM2_ISR_H_
#define CUSTOM_INCLUDE_CUSTOM_EPWM2_ISR_H_

#include "F28x_Project.h"

extern interrupt void epwm2_isr(void);



extern float hall_freq ;
extern int16_t hall_dir;

extern float Ts;

#endif /* CUSTOM_INCLUDE_CUSTOM_EPWM2_ISR_H_ */
