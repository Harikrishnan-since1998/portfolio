/*
 * custom_adc.h
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_ADC_H_
#define CUSTOM_INCLUDE_CUSTOM_ADC_H_

#include "F28x_Project.h"

extern Uint16 AdcaResult0;
extern Uint16 AdcaResult1;
extern Uint16 AdcaResult2;
extern Uint16 AdcaResult3;
extern Uint16 AdcaResult4;
extern Uint16 AdcaResult5;

extern Uint16 AdcbResult2;
extern Uint16 AdcbResult3;
extern Uint16 AdcbResult5;
extern Uint16 AdcbResult14;

extern Uint16 AdccResult2;
extern Uint16 AdccResult3;
extern Uint16 AdccResult5;
extern Uint16 AdccResult15;

extern Uint16 AdcdResult0;
extern Uint16 AdcdResult1;
extern Uint16 AdcdResult2;
extern Uint16 AdcdResult3;

extern void config_ADC(void);
extern void config_ADC_SOC_Epwm(void);
extern interrupt void adca1_isr(void);



#endif /* CUSTOM_INCLUDE_CUSTOM_ADC_H_ */
