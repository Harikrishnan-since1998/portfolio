/*
 * custom_protection.h
 *
 *  Created on: 10-Dec-2025
 *      Author: MC LAB
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_PROTECTION_H_
#define CUSTOM_INCLUDE_CUSTOM_PROTECTION_H_

#include "F28x_Project.h"
#include "math.h"

extern void protection(void);

extern float stop;
extern float current_max;

#endif /* CUSTOM_INCLUDE_CUSTOM_PROTECTION_H_ */
