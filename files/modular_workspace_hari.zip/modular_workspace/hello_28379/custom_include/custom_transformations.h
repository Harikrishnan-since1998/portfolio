/*
 * custom_transformations.h
 *
 *  Created on: 11-Dec-2025
 *      Author: MC LAB
 */

#ifndef CUSTOM_INCLUDE_CUSTOM_TRANSFORMATIONS_H_
#define CUSTOM_INCLUDE_CUSTOM_TRANSFORMATIONS_H_

extern void abc_alpha_beta_I(float ia1,float ib1,float ic1);
extern void alpha_beta_2_dq_current(void);
extern void dq_2_alpha_beta_m(void);
extern void alpha_beta_2_abc_m(void);
extern float midvalue(float u,float v, float w);

extern float mu1,mv1,mw1;


#endif /* CUSTOM_INCLUDE_CUSTOM_TRANSFORMATIONS_H_ */
