# FIXED

custom_source/custom_filters.obj: ../custom_source/custom_filters.c
custom_source/custom_filters.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_filters.h
custom_source/custom_filters.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h

../custom_source/custom_filters.c:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_filters.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h:

