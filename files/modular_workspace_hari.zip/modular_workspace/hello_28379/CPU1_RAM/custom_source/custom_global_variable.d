# FIXED

custom_source/custom_global_variable.obj: ../custom_source/custom_global_variable.c
custom_source/custom_global_variable.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h

../custom_source/custom_global_variable.c:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h:

