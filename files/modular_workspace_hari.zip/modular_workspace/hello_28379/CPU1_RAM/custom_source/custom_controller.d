# FIXED

custom_source/custom_controller.obj: ../custom_source/custom_controller.c
custom_source/custom_controller.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_controller.h
custom_source/custom_controller.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h
custom_source/custom_controller.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_filters.h

../custom_source/custom_controller.c:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_controller.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_filters.h:

