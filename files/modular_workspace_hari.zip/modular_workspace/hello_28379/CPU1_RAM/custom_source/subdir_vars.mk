################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../custom_source/custom_adc.c \
../custom_source/custom_controller.c \
../custom_source/custom_dac.c \
../custom_source/custom_dac_view.c \
../custom_source/custom_epwm.c \
../custom_source/custom_epwm2_isr.c \
../custom_source/custom_filters.c \
../custom_source/custom_global_variable.c \
../custom_source/custom_interrupts_config.c \
../custom_source/custom_protection.c \
../custom_source/custom_sense_adc_values.c \
../custom_source/custom_transformations.c 

C_DEPS += \
./custom_source/custom_adc.d \
./custom_source/custom_controller.d \
./custom_source/custom_dac.d \
./custom_source/custom_dac_view.d \
./custom_source/custom_epwm.d \
./custom_source/custom_epwm2_isr.d \
./custom_source/custom_filters.d \
./custom_source/custom_global_variable.d \
./custom_source/custom_interrupts_config.d \
./custom_source/custom_protection.d \
./custom_source/custom_sense_adc_values.d \
./custom_source/custom_transformations.d 

OBJS += \
./custom_source/custom_adc.obj \
./custom_source/custom_controller.obj \
./custom_source/custom_dac.obj \
./custom_source/custom_dac_view.obj \
./custom_source/custom_epwm.obj \
./custom_source/custom_epwm2_isr.obj \
./custom_source/custom_filters.obj \
./custom_source/custom_global_variable.obj \
./custom_source/custom_interrupts_config.obj \
./custom_source/custom_protection.obj \
./custom_source/custom_sense_adc_values.obj \
./custom_source/custom_transformations.obj 

OBJS__QUOTED += \
"custom_source\custom_adc.obj" \
"custom_source\custom_controller.obj" \
"custom_source\custom_dac.obj" \
"custom_source\custom_dac_view.obj" \
"custom_source\custom_epwm.obj" \
"custom_source\custom_epwm2_isr.obj" \
"custom_source\custom_filters.obj" \
"custom_source\custom_global_variable.obj" \
"custom_source\custom_interrupts_config.obj" \
"custom_source\custom_protection.obj" \
"custom_source\custom_sense_adc_values.obj" \
"custom_source\custom_transformations.obj" 

C_DEPS__QUOTED += \
"custom_source\custom_adc.d" \
"custom_source\custom_controller.d" \
"custom_source\custom_dac.d" \
"custom_source\custom_dac_view.d" \
"custom_source\custom_epwm.d" \
"custom_source\custom_epwm2_isr.d" \
"custom_source\custom_filters.d" \
"custom_source\custom_global_variable.d" \
"custom_source\custom_interrupts_config.d" \
"custom_source\custom_protection.d" \
"custom_source\custom_sense_adc_values.d" \
"custom_source\custom_transformations.d" 

C_SRCS__QUOTED += \
"../custom_source/custom_adc.c" \
"../custom_source/custom_controller.c" \
"../custom_source/custom_dac.c" \
"../custom_source/custom_dac_view.c" \
"../custom_source/custom_epwm.c" \
"../custom_source/custom_epwm2_isr.c" \
"../custom_source/custom_filters.c" \
"../custom_source/custom_global_variable.c" \
"../custom_source/custom_interrupts_config.c" \
"../custom_source/custom_protection.c" \
"../custom_source/custom_sense_adc_values.c" \
"../custom_source/custom_transformations.c" 


