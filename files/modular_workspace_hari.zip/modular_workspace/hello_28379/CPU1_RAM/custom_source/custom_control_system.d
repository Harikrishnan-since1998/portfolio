# FIXED

custom_source/custom_control_system.obj: ../custom_source/custom_control_system.c
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_control_system.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_transformations.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_align_rotor.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_controller.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_speed_estimation.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F28x_Project.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_typedefs.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_device.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/assert.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdarg.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stddef.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_adc.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_analogsubsys.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cla.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cmpss.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cputimer.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dac.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dcsm.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dma.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ecap.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_emif.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm_xbar.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_eqep.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_flash.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_gpio.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_i2c.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_input_xbar.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ipc.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_mcbsp.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_memconfig.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_nmiintrupt.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_output_xbar.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_piectrl.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_pievect.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sci.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sdfm.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_spi.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sysctrl.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_upp.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xbar.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xint.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_can.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Examples.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_GlobalPrototypes.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_cputimervars.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_EPwm_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Adc_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Emif_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Gpio_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_I2c_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Ipc_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Pie_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Dma_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_SysCtrl_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Upp_defines.h
custom_source/custom_control_system.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_defaultisr.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h
custom_source/custom_control_system.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm2_isr.h
custom_source/custom_control_system.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_protection.h

../custom_source/custom_control_system.c:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_control_system.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_transformations.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_align_rotor.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_controller.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_speed_estimation.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F28x_Project.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_typedefs.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_device.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/assert.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdarg.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stddef.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_adc.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_analogsubsys.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cla.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cmpss.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cputimer.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dac.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dcsm.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dma.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ecap.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_emif.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_eqep.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_flash.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_gpio.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_i2c.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_input_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ipc.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_mcbsp.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_memconfig.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_nmiintrupt.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_output_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_piectrl.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_pievect.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sci.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sdfm.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_spi.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sysctrl.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_upp.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xint.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_can.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Examples.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_GlobalPrototypes.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_cputimervars.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_EPwm_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Adc_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Emif_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Gpio_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_I2c_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Ipc_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Pie_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Dma_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_SysCtrl_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Upp_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_defaultisr.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm2_isr.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_protection.h:

