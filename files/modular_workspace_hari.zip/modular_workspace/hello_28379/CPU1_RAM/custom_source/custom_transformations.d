# FIXED

custom_source/custom_transformations.obj: ../custom_source/custom_transformations.c
custom_source/custom_transformations.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_transformations.h
custom_source/custom_transformations.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h

../custom_source/custom_transformations.c:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_transformations.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h:

