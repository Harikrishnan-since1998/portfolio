# FIXED

main.obj: ../main.c
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F28x_Project.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_typedefs.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_device.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/assert.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdarg.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stddef.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_adc.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_analogsubsys.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cla.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cmpss.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cputimer.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dac.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dcsm.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dma.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ecap.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_emif.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm_xbar.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_eqep.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_flash.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_gpio.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_i2c.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_input_xbar.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ipc.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_mcbsp.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_memconfig.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_nmiintrupt.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_output_xbar.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_piectrl.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_pievect.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sci.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sdfm.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_spi.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sysctrl.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_upp.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xbar.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xint.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_can.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Examples.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_GlobalPrototypes.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_cputimervars.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_EPwm_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Adc_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Emif_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Gpio_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_I2c_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Ipc_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Pie_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Dma_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_SysCtrl_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Upp_defines.h
main.obj: C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_defaultisr.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h
main.obj: C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_adc.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_dac.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm2_isr.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_interrupts_config.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_sense_adc_values.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_protection.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h
main.obj: E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_dac_view.h

../main.c:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F28x_Project.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_typedefs.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_device.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/assert.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_ti_config.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/linkage.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdarg.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_types.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/cdefs.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_types.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdbool.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stddef.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/stdint.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_stdint40.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/stdint.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_stdint.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/sys/_stdint.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_adc.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_analogsubsys.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cla.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cmpss.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_cputimer.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dac.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dcsm.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_dma.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ecap.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_emif.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_epwm_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_eqep.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_flash.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_gpio.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_i2c.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_input_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_ipc.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_mcbsp.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_memconfig.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_nmiintrupt.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_output_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_piectrl.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_pievect.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sci.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sdfm.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_spi.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_sysctrl.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_upp.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xbar.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_xint.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_headers/include/F2837xD_can.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Examples.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_GlobalPrototypes.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_cputimervars.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Cla_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_EPwm_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Adc_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Emif_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Gpio_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_I2c_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Ipc_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Pie_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Dma_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_SysCtrl_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_Upp_defines.h:

C:/ti/controlSUITE/device_support/F2837xD/v210/F2837xD_common/include/F2837xD_defaultisr.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/math.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/_defs.h:

C:/ti/ccs1230/ccs/tools/compiler/ti-cgt-c2000_22.6.0.LTS/include/machine/_limits.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_adc.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_dac.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_epwm2_isr.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_interrupts_config.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_sense_adc_values.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_protection.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_global_variable.h:

E:/Research_related_hardware/TI_related/modular_workspace/hello_28379/custom_include/custom_dac_view.h:

