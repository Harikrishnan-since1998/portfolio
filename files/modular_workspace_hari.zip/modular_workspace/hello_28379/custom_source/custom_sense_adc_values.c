/*
 * custom_sense_adc_values.c
 *
 *  Created on: 15-Nov-2025
 *      Author: Harikrishnan S
 */

#include "custom_sense_adc_values.h"
#include  "custom_global_variable.h"


 float sensor_1_slope=29.6318,
       sensor_2_slope=30.5438,
       sensor_1_c=63.75076,
       sensor_2_c=66.345; // from calibration experiment

 float adc_multiplier=7.326e-4; // 3/4095

 float calibration=0,ia_correction=0,ib_correction=0; // variables for calibrating current


 void current_sense(Uint16 adc_1,Uint16 adc_2){

     Ia = sensor_1_slope*adc_1*adc_multiplier - sensor_1_c - ia_correction;
     Ib = sensor_2_slope*adc_2*adc_multiplier - sensor_2_c - ib_correction;
     Ic = -(Ia+Ib);

 }

 void current_calibrate(Uint16 adc_1,Uint16 adc_2){

     if(calibration==1){
         ia_correction = sensor_1_slope*adc_1*adc_multiplier - sensor_1_c;
         ib_correction = sensor_2_slope*adc_2*adc_multiplier - sensor_2_c;
     }

 }


