/*
 * custom_interrupts_config.c
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */


#include "custom_interrupts_config.h"

//======================================================================================================================================
//Interrupt configuration
//======================================================================================================================================
void config_interrupts(void)
{


    EALLOW;                                         // This is needed to write to EALLOW protected registers

    PieVectTable.EPWM2_INT = &epwm2_isr;            //function for epwm2 interrupt

    EDIS;                                           // This is needed to disable write to EALLOW protected registers
//
// Map ADC ISR functions
//
    EALLOW;

    PieVectTable.ADCA1_INT = &adca1_isr;            //function for ADCA interrupt 1

    EDIS;

    // pg. 102 PIE Channel Mapping spruhm8i.pdf - Technical reference
                      // Timer 0
    IER |= M_INT1;

//
// Enable CPU INT3 which is connected to EPWM6-3 INT:
//
    IER |= M_INT3;                                  //Enable group 3 interrupts
//
// Enable CPU INT1 which is connected to ADC INT:
//
    IER |= M_INT1;                                  //Enable group 1 interrupts
//
// Enable EPWM INTn in the PIE: Group 3 interrupt 1-3
//
    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
    PieCtrlRegs.PIEIER3.bit.INTx2 = 1;
    PieCtrlRegs.PIEIER3.bit.INTx3 = 1;

//
// Enable ADC INTn in the PIE: Group 1 interrupt 1
//
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;

//
// Enable global Interrupts and higher priority real-time debug events:
//
    EINT;                                           // Enable Global interrupt INTM
    ERTM;                                           // Enable Global real time interrupt DBGM
}
