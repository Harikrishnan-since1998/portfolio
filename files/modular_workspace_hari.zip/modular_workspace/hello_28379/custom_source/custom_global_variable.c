/*
 * custom_global_variable.c
 *
 *  Created on: 10-Dec-2025
 *      Author: MC LAB
 */
#include"custom_global_variable.h"

float Ts = 100E-6;
float Ia=0,Ib=0,Ic=0; // variables for sensing current
float Ia_filtered=0,Ib_filtered=0,Ic_filtered=0; // variables for filtered current
int enable_protection =0; // variable to enable protection.

 float I_alpha=0,I_beta=0,I_d=0,I_q=0,
       m_alpha=0,m_beta=0,mu=0,mv=0,mw=0;    // variables for transformation
 float cos_rho_trans=1,sin_rho_trans=0;      // theta estimates

 float m_d=0,m_q=0; // controller outputs

 /* =======================
  * Speed Loop Variables
  * ======================= */
 float speed_ref=0;
 float speed_error = 0.0f, speed_measured = 0.0f, speed_prop = 0.0f;
 float KP_speed = 0.09f, KI_speed = 0.05f;
 float speed_error_prev = 0.0f, cont_integ_temp = 0.0f;
 float speed_integ = 0.0f;
 float Iq_ref = 0.0f;
 float iq_limit_pos = 8.0f, iq_limit_neg = -8.0f;
 int iq_integ_enable = 1;
 int speed_integ_enable=1;

 /* =======================
  * Iq Current Loop Variables
  * ======================= */
 float Iq_error = 0.0f, iq_prop = 0.0f;
 float KP_i = 0.3f, KI_i = 5.0f;
 float Iq_error_prev = 0.0f;
 float iq_integ = 0.0f;
 float mq_limit_pos = 0.8f, mq_limit_neg = -0.8f;

 /* =======================
  * Id Current Loop Variables
  * ======================= */
 int id_integ_enable = 1;
 float Id_error = 0.0f, Id_ref = 0.0f, id_prop = 0.0f;
 float KP_i_d = 0.02f, KI_i_d = 2.0f;
 float Id_error_prev = 0.0f;
 float id_integ = 0.0f;
 float md_limit_pos = 0.8f, md_limit_neg = -0.8f;

 /* =======================
  * Feedforward Terms
  * ======================= */
 float FF_Id = 0.0f, FF_Iq = 0.0f;

 /* =======================
  * DC Link Voltage
  * ======================= */
 float measured_dc_voltage = 48.0f;



  float start_control=0;
  float Ld, Lq, Kb,w_filtered;


