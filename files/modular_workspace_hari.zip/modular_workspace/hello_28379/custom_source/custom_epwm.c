/*
 * custom_epwm.c
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */


#include "custom_epwm.h"

unsigned int PWM_tbprd=0x9C4;

//======================================================================================================================================
//Initializing ePWM registers 1 to 6 and
//======================================================================================================================================
void config_EPwm()

{
    EALLOW;

    ClkCfgRegs.PERCLKDIVSEL.bit.EPWMCLKDIV = 0;     //epwmclk=sysclk

    EDIS;

//
// Enable ePWM1 to ePWM8
//
     CpuSysRegs.PCLKCR2.bit.EPWM1=1;
     CpuSysRegs.PCLKCR2.bit.EPWM2=1;
     CpuSysRegs.PCLKCR2.bit.EPWM3=1;
     CpuSysRegs.PCLKCR2.bit.EPWM4=1;
     CpuSysRegs.PCLKCR2.bit.EPWM5=1;
     CpuSysRegs.PCLKCR2.bit.EPWM6=1;
     CpuSysRegs.PCLKCR2.bit.EPWM7=1;
     CpuSysRegs.PCLKCR2.bit.EPWM8=1;
//
// Initialize GPIO pins for ePWM1 to ePWM8
// These functions are in the F2837xD_EPwm.c file
//
     InitEPwm1Gpio();                               //J4-40 and J4-39 (PWMOUT1A & PWMOUT1B)
     InitEPwm2Gpio();                               //J4-38 and J4-37 (PWMOUT2A & PWMOUT2B)
     InitEPwm3Gpio();                               //J4-36 and J4-35 (PWMOUT3A & PWMOUT3B)
     InitEPwm4Gpio();                               //J8-80 and J8-79 (PWMOUT4A & PWMOUT4B)
     InitEPwm5Gpio();                               //J8-78 and J8-77 (PWMOUT5A & PWMOUT5B)
     InitEPwm6Gpio();                               //J8-76 and J8-75 (PWMOUT6A & PWMOUT6B)
     InitEPwm7Gpio();                               //J4-32 and J4-31 (PWM BASED DAC1 and DAC2)
     InitEPwm8Gpio();                               //J8-72 and J8-71 (PWM BASED DAC3 and DAC4)


 // EPWM Module 1 configuration

     EPwm1Regs.TBPRD = PWM_tbprd;                   // Period = 1250 TBCLK counts (10kHz because up down counting)

     EPwm1Regs.TBCTL.bit.HSPCLKDIV = 0x2;           // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/4*1)=50M
     EPwm1Regs.TBCTL.bit.CLKDIV = 0x0;              // clkdiv=1
     EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // up down count mode
     EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Master module
     EPwm1Regs.TBCTL.bit.PRDLD = TB_SHADOW;
     EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;    // Sync down-stream module

     EPwm1Regs.TBPHS.bit.TBPHS = 0x0000;            // Set Phase register to zero

     EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
     EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
     EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD; // load on CTR=Zero
     EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD; // load on CTR=Zero

     EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;           // set actions for EPWM6A
     EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;
     EPwm1Regs.AQCTLB.bit.CAU = AQ_CLEAR;           // Set PWM2A on Zero
     EPwm1Regs.AQCTLB.bit.CAD = AQ_SET;

     EPwm1Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE; // enable Dead-band module
     EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;      // Active Hi complementary
     EPwm1Regs.DBRED.bit.DBRED = 100;
     EPwm1Regs.DBFED.bit.DBFED = 100;

// EPWM Module 2 configuration

     EPwm2Regs.TBPRD = PWM_tbprd;                   // Period = 1250 TBCLK counts (10kHz because up down counting)

     EPwm2Regs.TBCTL.bit.HSPCLKDIV = 0x2;           // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/4*1)=50M
     EPwm2Regs.TBCTL.bit.CLKDIV = 0x0;              // clkdiv=1
     EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // up down count mode
     EPwm2Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Master module
     EPwm2Regs.TBCTL.bit.PRDLD = TB_SHADOW;
     EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;    // Sync down-stream module

     EPwm2Regs.TBPHS.bit.TBPHS = 0x0000;            // Set Phase register to zero

     EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
     EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
     EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD; // load on CTR=Zero
     EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD; // load on CTR=Zero

     EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;           // set actions for EPWM6A
     EPwm2Regs.AQCTLA.bit.CAD = AQ_SET;
     EPwm2Regs.AQCTLB.bit.CAU = AQ_CLEAR;           // Set PWM2A on Zero
     EPwm2Regs.AQCTLB.bit.CAD = AQ_SET;

     EPwm2Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE; // enable Dead-band module
     EPwm2Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;      // Active Hi complementary
     EPwm2Regs.DBRED.bit.DBRED = 100;
     EPwm2Regs.DBFED.bit.DBFED = 100;


// EPWM Module 3 configuration

     EPwm3Regs.TBPRD = PWM_tbprd;                   // Period = 1250 TBCLK counts (10kHz because up down counting)

     EPwm3Regs.TBCTL.bit.HSPCLKDIV = 0x2;           // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/4*1)=50M
     EPwm3Regs.TBCTL.bit.CLKDIV = 0x0;              // clkdiv=1
     EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // up down count mode
     EPwm3Regs.TBCTL.bit.PHSEN = TB_DISABLE;        // Master module
     EPwm3Regs.TBCTL.bit.PRDLD = TB_SHADOW;
     EPwm3Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;    // Sync down-stream module

     EPwm3Regs.TBPHS.bit.TBPHS = 0x0000;            // Set Phase register to zero

     EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
     EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
     EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD; // load on CTR=Zero
     EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD; // load on CTR=Zero

     EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;           // set actions for EPWM6A
     EPwm3Regs.AQCTLA.bit.CAD = AQ_SET;
     EPwm3Regs.AQCTLB.bit.CAU = AQ_CLEAR;           // Set PWM2A on Zero
     EPwm3Regs.AQCTLB.bit.CAD = AQ_SET;

     EPwm3Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE; // enable Dead-band module
     EPwm3Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;      // Active Hi complementary
     EPwm3Regs.DBRED.bit.DBRED = 100;
     EPwm3Regs.DBFED.bit.DBFED = 100;

// EPWM Module 4 configuration

     EPwm4Regs.TBPRD = PWM_tbprd;                   // Period = 1250 TBCLK counts (10kHz because up down counting)

     EPwm4Regs.TBCTL.bit.HSPCLKDIV = 0x2;           // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/4*1)=50M
     EPwm4Regs.TBCTL.bit.CLKDIV = 0x0;              // clkdiv=1
     EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // up down count mode
     EPwm4Regs.TBCTL.bit.PHSEN = TB_ENABLE;         // Slave module
     EPwm4Regs.TBCTL.bit.PRDLD = TB_SHADOW;
     EPwm4Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;     // sync flow-through

     EPwm4Regs.TBPHS.bit.TBPHS = 0x0000;            // Set Phase register to zero

     EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
     EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
     EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // load on CTR=Zero
     EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;  // load on CTR=Zero

     EPwm4Regs.AQCTLA.bit.CAU = AQ_CLEAR;           // set actions for EPWM6A
     EPwm4Regs.AQCTLA.bit.CAD = AQ_SET;
     EPwm4Regs.AQCTLB.bit.CAU = AQ_CLEAR;           // Set PWM2A on Zero
     EPwm4Regs.AQCTLB.bit.CAD = AQ_SET;

     EPwm4Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE; // enable Dead-band module
     EPwm4Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;      // Active Hi complementary
     EPwm4Regs.DBRED.bit.DBRED = 40;
     EPwm4Regs.DBFED.bit.DBFED = 40;

// EPWM Module 5 configuration

     EPwm5Regs.TBPRD = PWM_tbprd;                   // Period = 1250 TBCLK counts (10kHz because up down counting)

     EPwm5Regs.TBCTL.bit.HSPCLKDIV = 0x2;           // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/4*1)=50M
     EPwm5Regs.TBCTL.bit.CLKDIV = 0x0;              // clkdiv=1
     EPwm5Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // up down count mode
     EPwm5Regs.TBCTL.bit.PHSEN = TB_ENABLE;         // Slave module
     EPwm5Regs.TBCTL.bit.PRDLD = TB_SHADOW;
     EPwm5Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;     // sync flow-through

     EPwm5Regs.TBPHS.bit.TBPHS = 0x0000;            // Set Phase register to zero

     EPwm5Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
     EPwm5Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
     EPwm5Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // load on CTR=Zero
     EPwm5Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;  // load on CTR=Zero

     EPwm5Regs.AQCTLA.bit.CAU = AQ_CLEAR;           // set actions for EPWM6A
     EPwm5Regs.AQCTLA.bit.CAD = AQ_SET;
     EPwm5Regs.AQCTLB.bit.CAU = AQ_CLEAR;           // Set PWM2A on Zero
     EPwm5Regs.AQCTLB.bit.CAD = AQ_SET;

     EPwm5Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE; // enable Dead-band module
     EPwm5Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;      // Active Hi complementary
     EPwm5Regs.DBRED.bit.DBRED = 40;
     EPwm5Regs.DBFED.bit.DBFED = 40;

// EPWM Module 6 configuration

     EPwm6Regs.TBPRD = PWM_tbprd;                   // Period = 1250 TBCLK counts (10kHz because up down counting)

     EPwm6Regs.TBCTL.bit.HSPCLKDIV = 0x2;           // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/4*1)=50M
     EPwm6Regs.TBCTL.bit.CLKDIV = 0x0;              // clkdiv=1
     EPwm6Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // up down count mode
     EPwm6Regs.TBCTL.bit.PHSEN = TB_ENABLE;         // Slave module
     EPwm6Regs.TBCTL.bit.PRDLD = TB_SHADOW;
     EPwm6Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;     // sync flow-through

     EPwm6Regs.TBPHS.bit.TBPHS = 0x0000;            // Set Phase register to zero

     EPwm6Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
     EPwm6Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
     EPwm6Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // load on CTR=Zero
     EPwm6Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;  // load on CTR=Zero

     EPwm6Regs.AQCTLA.bit.CAU = AQ_CLEAR;           // set actions for EPWM6A
     EPwm6Regs.AQCTLA.bit.CAD = AQ_SET;
     EPwm6Regs.AQCTLB.bit.CAU = AQ_CLEAR;           // Set PWM2A on Zero
     EPwm6Regs.AQCTLB.bit.CAD = AQ_SET;

     EPwm6Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE; // enable Dead-band module
     EPwm6Regs.DBCTL.bit.POLSEL = DB_ACTV_HIC;      // Active Hi complementary
     EPwm6Regs.DBRED.bit.DBRED = 40;
     EPwm6Regs.DBFED.bit.DBFED = 40;

//PWM duty cycle register

     EPwm1Regs.CMPA.bit.CMPA = 0;                   // adjust duty for output EPWM6A
     EPwm2Regs.CMPA.bit.CMPA = 0;                   // adjust duty for output EPWM7A
     EPwm3Regs.CMPA.bit.CMPA = 0;                   // adjust duty for output EPWM8A

     EPwm4Regs.CMPA.bit.CMPA = 0;                   // adjust duty for output EPWM6A
     EPwm5Regs.CMPA.bit.CMPA = 0;                   // adjust duty for output EPWM7A
     EPwm6Regs.CMPA.bit.CMPA = 0;                   // adjust duty for output EPWM8A


//configure interrupt from the pwm module

     EPwm2Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;      // Select INT on Zero event
     EPwm2Regs.ETSEL.bit.INTEN = 1;                 // Enable INT
     EPwm2Regs.ETPS.bit.INTPRD = ET_1ST;            // Generate INT on 1st event

// ISR functions found within this file.

     EALLOW;                                        // This is needed to write to EALLOW protected registers
     PieVectTable.EPWM2_INT = &epwm2_isr;
     EDIS;                                          // This is needed to disable write to EALLOW protected registers

// Enable CPU INT3 which is connected to EPWM6-3 INT:

     IER |= M_INT3;

// Enable EPWM INTn in the PIE: Group 3 interrupt 1-3

     PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
//   PieCtrlRegs.PIEIER3.bit.INTx2 = 1;
//   PieCtrlRegs.PIEIER3.bit.INTx3 = 1;

// Enable global Interrupts and higher priority real-time debug events:

     EINT;                                          // Enable Global interrupt INTM
     ERTM;                                          // Enable Global real time interrupt DBGM

//Trip action initialization

//        EALLOW;
//
//        EPwm2Regs.TZCTL.bit.TZA = 0x2;            // Trip action set to force-low for output A
//        EPwm2Regs.TZCTL.bit.TZB = 0x2;            // Trip action set to force-low for output B
//        EPwm2Regs.TZSEL.bit.OSHT1 = 0x1;          // TZ1 configured for OSHT trip of ePWM1
//        EPwm2Regs.TZCLR.bit.OST = 0x1;            // Clear OST flag just in case
//
//        EPwm7Regs.TZCTL.bit.TZA = 0x2;            // Trip action set to force-low for output A
//        EPwm7Regs.TZCTL.bit.TZB = 0x2;            // Trip action set to force-low for output B
//        EPwm7Regs.TZSEL.bit.OSHT1 = 0x1;          // TZ1 configured for OSHT trip of ePWM1
//        EPwm7Regs.TZCLR.bit.OST = 0x1;            // Clear OST flag just in case
//
//
//        EPwm8Regs.TZCTL.bit.TZA = 0x2;            // Trip action set to force-low for output A
//        EPwm8Regs.TZCTL.bit.TZB = 0x2;            // Trip action set to force-low for output B
//        EPwm8Regs.TZSEL.bit.OSHT1 = 0x1;          // TZ1 configured for OSHT trip of ePWM1
//        EPwm8Regs.TZCLR.bit.OST = 0x1;            // Clear OST flag just in case
//
//        EDIS;

//ADC SOC enable
     EALLOW;
        // Assumes ePWM clock is already enabled
     EPwm2Regs.ETSEL.bit.SOCAEN = 1;                // Disable SOC on A group
     EPwm2Regs.ETSEL.bit.SOCASEL= 3;                // Select SOC on up-count
     EPwm2Regs.ETPS.bit.SOCAPRD = 1;                // Generate pulse on 1st event

     EDIS;

}

void update_pwm(float mu,float mv, float mw){
    EPwm1Regs.CMPA.bit.CMPA = 1250*(1+mu);                    // adjust duty for output EPWM1A
    EPwm2Regs.CMPA.bit.CMPA = 1250*(1+mv);
    EPwm3Regs.CMPA.bit.CMPA = 1250*(1+mw);
}
