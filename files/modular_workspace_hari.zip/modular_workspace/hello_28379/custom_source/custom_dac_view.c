/*
 * custom_dac_view.c
 *
 *  Created on: 11-Dec-2025
 *      Author: MC LAB
 */

#include "custom_global_variable.h"
#include "custom_dac.h"
float mode=0;

void dac_view(void){

    if(mode==0){
         DacaRegs.DACVALS.all = (float)((1+mu)*4095/2.0) ;
         DacbRegs.DACVALS.all = (float)((1+mv)*4095/2.0) ;}

    if(mode==1){
         DacaRegs.DACVALS.all = (float)((15+Iq_ref)*4095/30.0) ;
         DacbRegs.DACVALS.all = (float)((15+I_q)*4095/30.0) ;}

    if(mode==2){
         DacaRegs.DACVALS.all = (float)((15+Id_ref)*4095/30.0) ;
         DacbRegs.DACVALS.all = (float)((15+I_d)*4095/30.0) ;}

    if(mode==3){
         DacaRegs.DACVALS.all = (float)(speed_ref*(4095/700.0)) ;
         DacbRegs.DACVALS.all = (float)(w_filtered*4095/700.0) ;}


}


