/*
 * custom_controller.c
 *
 *  Created on: 11-Dec-2025
 *      Author: MC LAB
 */
#include "custom_controller.h"
#include "custom_global_variable.h"
#include "custom_filters.h"


// ====================================================================================================
// Speed controller
void Speed_Controller(void){


    // Calculate speed error
    speed_measured = w_filtered;
    speed_error = speed_ref - speed_measured;               //speed error

    //PI controller
    speed_prop = KP_speed * speed_error;                // kp time speed error
    cont_integ_temp = (KI_speed * Ts / 2.0) * (speed_error + speed_error_prev); //Ki times speed error

    if(speed_integ_enable == 1)
        {
            speed_integ = speed_integ + cont_integ_temp;            //integrator anti-windup enables during saturation and fault
        }
    Iq_ref = speed_prop + speed_integ;

    //Anti-windup

    if((speed_error > 0) && (Iq_ref > iq_limit_pos))     // iq_limit_pos --> iq_limit_positive
        speed_integ_enable = 0;
    else if((speed_error < 0) && (Iq_ref< iq_limit_neg))  // iq_limit_neg --> iq_limit_negative
        speed_integ_enable = 0;
    else
        speed_integ_enable = 1;

        //Clamping

    if(Iq_ref > iq_limit_pos)
        Iq_ref = iq_limit_pos;
    else if(Iq_ref < iq_limit_neg)
        Iq_ref = iq_limit_neg;

    speed_error_prev = speed_error;

}

// =======================================================================================
// Field oriented control(FOC)

void FOC_Control(void)
{
    //  Feed forward compensation (Decoupling terms)
    FF_Id = ( w_filtered*Lq*I_q)*(2.0/measured_dc_voltage);
    FF_Iq = (w_filtered*Ld*I_d+w_filtered*Kb)*(2.0/measured_dc_voltage);

    //*********************************************************************
        // PI control for q-axis
    //*********************************************************************
    // Calculate Iq error
    Iq_error = Iq_ref - I_q;

    iq_prop = KP_i * Iq_error; //proportional Kp
    cont_integ_temp = (KI_i * Ts / 2.0) * (Iq_error + Iq_error_prev); // integration Ki

    if(iq_integ_enable == 1)
    {
     iq_integ = iq_integ + cont_integ_temp;
    }
     m_q = iq_prop + iq_integ-FF_Iq;

//Anti-windup

    if((Iq_error> 0) && (m_q> md_limit_pos))
     iq_integ_enable = 0;
    else if((Iq_error < 0) && (m_q< md_limit_neg))
     iq_integ_enable = 0;
    else
     iq_integ_enable = 1;

//Clamps

    if(m_q > mq_limit_pos)
     m_q = mq_limit_pos;
    else if(m_q < mq_limit_neg)
     m_q = mq_limit_neg;

    Iq_error_prev = Iq_error;



//*********************************************************************
    // PI control for d-axis
//*********************************************************************

    // Calculate Id error
    Id_error = Id_ref - I_d;

   // PI controller
    id_prop = KP_i_d * Id_error;   //proportional kp
    cont_integ_temp = (KI_i_d * Ts / 2.0) * (Id_error + Id_error_prev); // integration ki

    if (id_integ_enable == 1 )
    {
    id_integ = id_integ + cont_integ_temp;
    }
    m_d = id_prop + id_integ+FF_Id;

    // Anti-windup
    if ((Id_error > 0) && (m_d > md_limit_pos))
     id_integ_enable = 0;
    else if ((Id_error < 0) && (m_d < md_limit_neg))
     id_integ_enable = 0;
    else
     id_integ_enable = 1;

    // Clamps
    if (m_d > md_limit_pos)
     m_d = md_limit_pos;
    else if (m_d < md_limit_neg)
     m_d = md_limit_neg;

    Id_error_prev = Id_error;

}

void initialize_variables(){

    start_control=0;
    speed_error=0.0;speed_prop=0.0;speed_error_prev=0.0;cont_integ_temp=0.0;
    speed_integ=0.0;Iq_ref=0.0;
    iq_integ_enable =1;
    Iq_error=0.0;iq_prop=0.0;Iq_error_prev=0.0;
    iq_integ=0.0;id_integ_enable=1;
    Id_error=0.0;Id_ref=0.0;id_prop=0.0;
    Id_error_prev=0.0;id_integ=0.0, m_d=0,m_q=0;

     mu=0;mv=0;mw=0;
     alpha =0;
     xprev=0;yprev=0;
     alpha_I_u =0;
     xprev_I_u=0;yprev_I_u=0;
     alpha_I_w =0;
     xprev_I_w=0;yprev_I_w=0;
     alpha_I_v =0;
     xprev_I_v=0;yprev_I_v=0;



}





