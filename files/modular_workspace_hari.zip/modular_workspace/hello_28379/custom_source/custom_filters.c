/*
 * custom_filters.c
 *
 *  Created on: 10-Dec-2025
 *      Author: MC LAB
 */

#include"custom_filters.h"
#include"custom_global_variable.h"

float alpha_I_u =0;
float x_I_u,xprev_I_u=0,y_I_u,yprev_I_u=0;
float alpha_I_w =0;
float x_I_w,xprev_I_w=0,y_I_w,yprev_I_w=0;
float alpha_I_v =0;
float x_I_v,xprev_I_v=0,y_I_v,yprev_I_v=0;
float alpha =0;
float x,xprev=0,y,yprev=0;




float first_order_filter_I_u(float x_I_u,float cutoff){

    alpha_I_u = 1/(PI*cutoff*Ts);
    y_I_u     = (1/(1+alpha_I_u))*((alpha_I_u-1)*(yprev_I_u)+xprev_I_u+x_I_u);
    yprev_I_u = y_I_u;
    xprev_I_u = x_I_u;

    return y_I_u;

}

float first_order_filter_I_w(float x_I_w,float cutoff){

    alpha_I_w = 1/(PI*cutoff*Ts);
    y_I_w     = (1/(1+alpha_I_w))*((alpha_I_w-1)*(yprev_I_w)+xprev_I_w+x_I_w);
    yprev_I_w = y_I_w;
    xprev_I_w = x_I_w;

    return y_I_w;

}

float first_order_filter_I_v(float x_I_v,float cutoff){

    alpha_I_v = 1/(PI*cutoff*Ts);
    y_I_v     = (1/(1+alpha_I_v))*((alpha_I_v-1)*(yprev_I_v)+xprev_I_v+x_I_v);
    yprev_I_v = y_I_v;
    xprev_I_v = x_I_v;

    return y_I_v;

}

float first_order_filter_w(float x,float cutoff){
    alpha = 1/(PI*cutoff*Ts);

    y = (1/(1+alpha))*((alpha-1)*(yprev)+xprev+x);
    yprev = y;
    xprev = x;

    return y;

}

