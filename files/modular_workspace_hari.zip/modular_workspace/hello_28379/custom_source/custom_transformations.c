/*
 * custom_transformations.c
 *
 *  Created on: 11-Dec-2025
 *      Author: MC LAB
 */


#include "custom_transformations.h"
#include "custom_global_variable.h"

float mu1=0,mv1=0,mw1=0;

void abc_alpha_beta_I(float ia1,float ib1,float ic1)
{
I_alpha=(0.6666*ia1-0.33*ib1-0.33*ic1);
I_beta=(0.577*ib1-0.577*ic1);
}

void alpha_beta_2_dq_current(void)
{
I_d = (I_alpha*cos_rho_trans) + (I_beta*sin_rho_trans);
I_q = (I_beta*cos_rho_trans) - (I_alpha*sin_rho_trans);
}

void dq_2_alpha_beta_m(void){
    m_alpha = (m_d*cos_rho_trans) - (m_q*sin_rho_trans);
    m_beta =  (m_d*sin_rho_trans) + (m_q*cos_rho_trans);
}
void alpha_beta_2_abc_m(void){
    mu1 =  m_alpha;
    mv1 = (-(m_alpha*0.5)+ (m_beta * 0.866));
    mw1 = (-(m_alpha*0.5)- (m_beta * 0.866));

    mu= mu1+midvalue(mu1,mv1,mw1);
    mv= mv1+midvalue(mu1,mv1,mw1);
    mw= mw1+midvalue(mu1,mv1,mw1);


}

float midvalue(float u,float v, float w)
{
    float mid=0;
    if((u>v && v>w) || (w>v && v>u))
    {
        mid=v;
    }
    else if ((u>w && w>v) ||( v>w && w>u))
    {
        mid=w;
    }
    else
    {
       mid =u;
    }
    return mid/2.0;
}
