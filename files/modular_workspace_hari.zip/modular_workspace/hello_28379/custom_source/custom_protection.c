/*
 * custom_protection.c
 *
 *  Created on: 10-Dec-2025
 *      Author: MC LAB
 */


#include "custom_protection.h"
#include "custom_epwm2_isr.h"
#include "custom_adc.h"
#include "custom_sense_adc_values.h"
#include "custom_epwm2_isr.h"
#include "custom_epwm.h"
#include "custom_global_variable.h"
#include "custom_controller.h"

float stop = 0;
float current_max = 15;


/* we are disabling over current protection during the align rotor period*/

void protection(void){

   // if(AdcaResult3==4095){stop=1;}

    if(enable_protection==1){
        if(Ia>current_max || Ia<-current_max ||
          Ib>current_max || Ib<-current_max ||
          Ic>current_max || Ic<-current_max ){stop=1;}
    }
    if(stop==1){
       update_pwm(-1,-1,-1);
       initialize_variables();
    }
 }
