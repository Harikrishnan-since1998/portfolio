/*
 * custom_dac.c
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */

#include "custom_dac.h"

unsigned int PWM_DAC_PRD = 0x4E2;
float PWMdac1temp, PWMdac2temp, PWMdac3temp, PWMdac4temp;


//======================================================================================================================================
// epwm2_isr - EPWM2 ISR to update compare values
//======================================================================================================================================

void Update_PWM_DAC(float PWMDAC1,float PWMDAC2,float PWMDAC3,float PWMDAC4)

{
    EPwm7Regs.CMPB.bit.CMPB = PWMDAC4;              // update PWM dac4, J4-31
    EPwm7Regs.CMPA.bit.CMPA = PWMDAC3;              // update PWM dac3, J4-32
    EPwm8Regs.CMPB.bit.CMPB = PWMDAC2;              // update PWM dac2, J8-31
    EPwm8Regs.CMPA.bit.CMPA = PWMDAC1;              // update PWM dac1, J8-32
}



//======================================================================================================================================
//Initializing PWM based DAC Registers (PWM 7 and PWM 8)
//======================================================================================================================================
void config_PWM_DAC(void)
{
//
// PWM DAC 3 and DAC 4 config
//
    EPwm7Regs.TBPRD = PWM_DAC_PRD;                  // Period = 625 TBCLK counts (80kHz because up counting)

    EPwm7Regs.TBCTL.bit.HSPCLKDIV = 0x1;            // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/2*1)=100M
    EPwm7Regs.TBCTL.bit.CLKDIV = 0x0;               // clkdiv=1
    EPwm7Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;      // up down count mode
    EPwm7Regs.TBCTL.bit.PHSEN = TB_ENABLE;          // Slave module
    EPwm7Regs.TBCTL.bit.PRDLD = TB_SHADOW;
    EPwm7Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_DISABLE; // sync flow-through

    EPwm7Regs.TBPHS.bit.TBPHS = 0x0000;             // Set Phase register to zero

    EPwm7Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm7Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm7Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;   // load on CTR=Zero
    EPwm7Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;   // load on CTR=Zero

    EPwm7Regs.AQCTLA.bit.CAU = AQ_CLEAR;            // set actions for EPWM6A
    EPwm7Regs.AQCTLA.bit.ZRO = AQ_SET;
    EPwm7Regs.AQCTLB.bit.CAU = AQ_CLEAR;            // Set PWM2A on Zero
    EPwm7Regs.AQCTLB.bit.ZRO = AQ_SET;


    EPwm7Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;      // enable Dead-band module
    EPwm7Regs.DBCTL.bit.POLSEL = DB_ACTV_HI;        // Active Hi complementary
    EPwm7Regs.DBRED.bit.DBRED = 0;
    EPwm7Regs.DBFED.bit.DBFED = 0;

//
// PWM DAC 1 and DAC 2 config
//
    EPwm8Regs.TBPRD = PWM_DAC_PRD;                  // Period = 625 TBCLK counts (80kHz because up counting)

    EPwm8Regs.TBCTL.bit.HSPCLKDIV = 0x1;            // tbclk=epwmclk/(HSPCLKDIV*CLKDIV)=(200M/2*1)=100M
    EPwm8Regs.TBCTL.bit.CLKDIV = 0x0;               // clkdiv=1
    EPwm8Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;      // up down count mode
    EPwm8Regs.TBCTL.bit.PHSEN = TB_ENABLE;          // Slave module
    EPwm8Regs.TBCTL.bit.PRDLD = TB_SHADOW;
    EPwm8Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_DISABLE; // sync flow-through

    EPwm8Regs.TBPHS.bit.TBPHS = 0x0000;             // Set Phase register to zero

    EPwm8Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm8Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm8Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;   // load on CTR=Zero
    EPwm8Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;   // load on CTR=Zero

    EPwm8Regs.AQCTLA.bit.CAU = AQ_CLEAR;            // set actions for EPWM6A
    EPwm8Regs.AQCTLA.bit.ZRO = AQ_SET;
    EPwm8Regs.AQCTLB.bit.CAU = AQ_CLEAR;            // Set PWM2A on Zero
    EPwm8Regs.AQCTLB.bit.ZRO = AQ_SET;


    EPwm8Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;      // enable Dead-band module
    EPwm8Regs.DBCTL.bit.POLSEL = DB_ACTV_HI;        // Active Hi complementary
    EPwm8Regs.DBRED.bit.DBRED = 0;
    EPwm8Regs.DBFED.bit.DBFED = 0;
}

//======================================================================================================================================
//initializing 12 bit buffered DAC registers (Launch pad  pin no J3-30 and J7-30)
//======================================================================================================================================
void config_DAC(void)
{
    EALLOW;

    DacaRegs.DACCTL.bit.DACREFSEL = 1;
    DacaRegs.DACOUTEN.bit.DACOUTEN = 1;
    DacaRegs.DACVALS.all = 0;
    DacbRegs.DACCTL.bit.DACREFSEL = 1;
    DacbRegs.DACOUTEN.bit.DACOUTEN = 1;
    DacbRegs.DACVALS.all = 0;
//       DaccRegs.DACCTL.bit.DACREFSEL = 1;
//       DaccRegs.DACOUTEN.bit.DACOUTEN = 0;
//       DaccRegs.DACVALS.all = 0;
     DELAY_US(20); // Delay for buffered DAC to power up

 EDIS;
}

