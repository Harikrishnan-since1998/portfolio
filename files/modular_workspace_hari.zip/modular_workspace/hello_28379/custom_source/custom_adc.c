/*
 * custom_adc.c
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */

#include "custom_adc.h"

#include "F28x_Project.h"

Uint16 AdcaResult0;
Uint16 AdcaResult1;
Uint16 AdcaResult2;
Uint16 AdcaResult3;
Uint16 AdcaResult4;
Uint16 AdcaResult5;

Uint16 AdcbResult2;
Uint16 AdcbResult3;
Uint16 AdcbResult5;
Uint16 AdcbResult14;

Uint16 AdccResult2;
Uint16 AdccResult3;
Uint16 AdccResult5;
Uint16 AdccResult15;

Uint16 AdcdResult0;
Uint16 AdcdResult1;
Uint16 AdcdResult2;
Uint16 AdcdResult3;



void config_ADC(void);
void config_ADC_SOC_Epwm(void);
interrupt void adca1_isr(void);

//======================================================================================================================================
// Initializing ADC registers - Write ADC configurations and power up the ADC for both
// ADC A, ADC B and ADC C
//======================================================================================================================================


void config_ADC(void)
{
    EALLOW;
//
//write configurations
//
    AdcaRegs.ADCCTL2.bit.PRESCALE = 6;          //set ADCCLK divider to /4
    AdcbRegs.ADCCTL2.bit.PRESCALE = 6;          //set ADCCLK divider to /4
    AdccRegs.ADCCTL2.bit.PRESCALE = 6;          //set ADCCLK divider to /4
    AdcdRegs.ADCCTL2.bit.PRESCALE = 6;          //set ADCCLK divider to /4

    AdcSetMode(ADC_ADCA, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);
    AdcSetMode(ADC_ADCB, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);
    AdcSetMode(ADC_ADCC, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);
    AdcSetMode(ADC_ADCD, ADC_RESOLUTION_12BIT, ADC_SIGNALMODE_SINGLE);

//
//Set pulse positions to late
//
    AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;
    AdcbRegs.ADCCTL1.bit.INTPULSEPOS = 1;
    AdccRegs.ADCCTL1.bit.INTPULSEPOS = 1;
    AdcdRegs.ADCCTL1.bit.INTPULSEPOS = 1;

//
//power up the ADC
//
    AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    AdcbRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    AdccRegs.ADCCTL1.bit.ADCPWDNZ = 1;
    AdcdRegs.ADCCTL1.bit.ADCPWDNZ = 1;

//
//delay for 1ms to allow ADC time to power up
//
    DELAY_US(1000);

    EDIS;
}

//======================================================================================================================================
// Setup epwm 2 as ADC SOC - Setup ADC EPWM acquisition window
//======================================================================================================================================

void config_ADC_SOC_Epwm(void)
{
    Uint16 acqps;

//
// Determine minimum acquisition window (in SYSCLKS) based on resolution
//
    if(ADC_RESOLUTION_12BIT == AdcaRegs.ADCCTL2.bit.RESOLUTION)
    {
        acqps = 30;                             //30* 1/200M=150ns
    }
    else                                        //resolution is 16-bit
    {
        acqps = 63;                             //320ns
    }

//
//Select the channels to convert  analog data(total 17 useful ADC pins in version 1.1)
// 2 ADC pins are used as DAC (A0 and A1), only 15 ADC pins are available for A to D conversion
//
    EALLOW;
//ADC a SOC select
//ADCA0 pin used as DAC1
    AdcaRegs.ADCSOC0CTL.bit.CHSEL = 0;          //SOC0 will convert pin A0
    AdcaRegs.ADCSOC0CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C
//ADCA1 pin used as DAC2
    AdcaRegs.ADCSOC1CTL.bit.CHSEL = 1;          //SOC1 will convert pin A1
    AdcaRegs.ADCSOC1CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C
//ADCA2 pin is tied to Vref+. so, not possible to use this pin in version 1.1
    AdcaRegs.ADCSOC2CTL.bit.CHSEL = 2;          //SOC2 will convert pin A2
    AdcaRegs.ADCSOC2CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC2CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcaRegs.ADCSOC3CTL.bit.CHSEL = 3;          //SOC3 will convert pin A3
    AdcaRegs.ADCSOC3CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC3CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcaRegs.ADCSOC4CTL.bit.CHSEL = 4;          //SOC4 will convert pin A4
    AdcaRegs.ADCSOC4CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC4CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcaRegs.ADCSOC5CTL.bit.CHSEL = 5;          //SOC5 will convert pin A5
    AdcaRegs.ADCSOC5CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcaRegs.ADCSOC5CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

//ADC a interrupt select

    AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 5;      //end of SOC5 will set INT1 flag
    AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;        //enable INT1 flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;      //make sure INT1 flag is cleared
    AdcaRegs.ADCINTSEL1N2.bit.INT1CONT= 0;

//ADC b SOC select

    AdcbRegs.ADCSOC2CTL.bit.CHSEL = 2;          //SOC0 will convert pin B2
    AdcbRegs.ADCSOC2CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcbRegs.ADCSOC2CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcbRegs.ADCSOC3CTL.bit.CHSEL = 3;          //SOC1 will convert pin B3
    AdcbRegs.ADCSOC3CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcbRegs.ADCSOC3CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C
//ADC b4 has routing problem on board version 1.1. so, dont use
    AdcbRegs.ADCSOC5CTL.bit.CHSEL = 5;          //SOC5 will convert pin B5
    AdcbRegs.ADCSOC5CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcbRegs.ADCSOC5CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcbRegs.ADCSOC14CTL.bit.CHSEL = 14;        //SOC14 will convert pin A14
    AdcbRegs.ADCSOC14CTL.bit.ACQPS = acqps;     //sample window is 100 SYSCLK cycles
    AdcbRegs.ADCSOC14CTL.bit.TRIGSEL = 7;       //trigger on ePWM2 SOCA/C

//ADC c SOC select

    AdccRegs.ADCSOC2CTL.bit.CHSEL = 2;          //SOC2 will convert pin C2
    AdccRegs.ADCSOC2CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdccRegs.ADCSOC2CTL.bit.TRIGSEL = 1;        //trigger on timer(0) when =1 and when=7 trigger on ePWM2 SOCA/C

    // Enable ADC interrupt for SOC2
    AdccRegs.ADCINTSEL1N2.bit.INT2SEL = 2;  // EOC2 triggers INT2
    AdccRegs.ADCINTSEL1N2.bit.INT2E = 1;    // Enable ADCINT2


    AdccRegs.ADCSOC3CTL.bit.CHSEL = 3;          //SOC3 will convert pin C3
    AdccRegs.ADCSOC3CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdccRegs.ADCSOC3CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C
//ADC c4 has routing problem on board version 1.1. so, dont use
    AdccRegs.ADCSOC5CTL.bit.CHSEL = 5;          //SOC5 will convert pin C5
    AdccRegs.ADCSOC5CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdccRegs.ADCSOC5CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdccRegs.ADCSOC15CTL.bit.CHSEL = 15;        //SOC15 will convert pin A15
    AdccRegs.ADCSOC15CTL.bit.ACQPS = acqps;     //sample window is 100 SYSCLK cycles
    AdccRegs.ADCSOC15CTL.bit.TRIGSEL = 7;       //trigger on ePWM2 SOCA/C

//ADC d SOC select

    AdcdRegs.ADCSOC0CTL.bit.CHSEL = 0;          //SOC0 will convert pin D0
    AdcdRegs.ADCSOC0CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcdRegs.ADCSOC0CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcdRegs.ADCSOC1CTL.bit.CHSEL = 1;          //SOC1 will convert pin D1
    AdcdRegs.ADCSOC1CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcdRegs.ADCSOC1CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcdRegs.ADCSOC2CTL.bit.CHSEL = 2;          //SOC2 will convert pin D2
    AdcdRegs.ADCSOC2CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcdRegs.ADCSOC2CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    AdcdRegs.ADCSOC3CTL.bit.CHSEL = 3;          //SOC3 will convert pin D3
    AdcdRegs.ADCSOC3CTL.bit.ACQPS = acqps;      //sample window is 100 SYSCLK cycles
    AdcdRegs.ADCSOC3CTL.bit.TRIGSEL = 7;        //trigger on ePWM2 SOCA/C

    EDIS;
}

//======================================================================================================================================
// adca1_isr - Read ADC Buffer in ISR
//======================================================================================================================================

interrupt void adca1_isr(void)
{


//ADCa results (NOTE THAT IN V1.1, silk screen markings are wrong for ADC pins, so the correct pin assignment is written here)

    AdcaResult0= AdcaResultRegs.ADCRESULT0;             //J3-30, ADCINA0 (configured as DACA)
    AdcaResult1= AdcaResultRegs.ADCRESULT1;             //J7-70, ADCINA1 (configured as DACB)
    AdcaResult2= AdcaResultRegs.ADCRESULT2;             //J3-29, ADCINA2 (tied to vref+ in layout)
    AdcaResult3= AdcaResultRegs.ADCRESULT3;             //J3-26, ADCINA3
    AdcaResult4= AdcaResultRegs.ADCRESULT4;             //J7-69, ADCINA4
    AdcaResult5= AdcaResultRegs.ADCRESULT5;             //J7-66, ADCINA5

//ADCb results

    AdcbResult2= AdcbResultRegs.ADCRESULT2;             //J3-28, ADCINB2
    AdcbResult3= AdcbResultRegs.ADCRESULT3;             //J3-25, ADCINB3
    AdcbResult5= AdcbResultRegs.ADCRESULT5;             //J7-65, ADCINB5
    AdcbResult14= AdcbResultRegs.ADCRESULT14;           //J3-23, ADCINB14

//ADCc results

    AdccResult2= AdccResultRegs.ADCRESULT2;             //J3-27, ADCINC2
    AdccResult3= AdccResultRegs.ADCRESULT3;             //J3-25, ADCINC3
    AdccResult5= AdccResultRegs.ADCRESULT5;             //J7-67, ADCINC5
    AdccResult15= AdccResultRegs.ADCRESULT15;           //J7-63, ADCINC15

//ADCc results

    AdcdResult0= AdcdResultRegs.ADCRESULT0;             //J21-1, ADCIND0
    AdcdResult1= AdcdResultRegs.ADCRESULT1;             //J21-2, ADCIND1
    AdcdResult2= AdcdResultRegs.ADCRESULT2;             //J21-3, ADCIND2
    AdcdResult3= AdcdResultRegs.ADCRESULT3;             //J21-4, ADCIND3




//clear INT1 flag
    AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

// Acknowledge this interrupt to receive more interrupts from group 1

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}


