/*
 * custom_epwm2_isr.c
 *
 *  Created on: 03-Nov-2025
 *      Author: Harikrishnan S
 */


#include "custom_epwm2_isr.h"
#include "custom_epwm.h"
#include "math.h"
#include "custom_adc.h"
#include "custom_dac.h"
#include "custom_sense_adc_values.h"
#include "custom_global_variable.h"
#include "custom_filters.h"
#include "custom_controller.h"
#include "custom_transformations.h"


float m1=0.5,m2=0.5,m3=0.5;
float va,vb,vc;
int choice =0;

float wt =0;


interrupt void epwm2_isr(void)
{
    // Measure_Hall_Speed(26, 27, 25, &hall_freq, &hall_dir);

/*----------sense current from adc----------------*/
    current_sense(AdccResult15,AdcbResult5);

/*----------calibrate current sensor---------------*/
// Make the variable calibration =1, then 0 via the expression window

    current_calibrate(AdccResult15,AdcbResult5);


/*----------Filter sensed currents----------------*/
    Ia_filtered= first_order_filter_I_u(Ia,1000);
    Ib_filtered= first_order_filter_I_v(Ib,1000);
    Ic_filtered= first_order_filter_I_w(Ic,1000);

    //test_speed_estimation(); // For test purposes


    //update_pwm()


// test code for checking PWM

wt = wt+2*PI*Ts;
if(wt>2*PI){wt=0;}

if(choice==1){
    va = m1*sin(wt);
    vb = m2*sin(wt+2*PI/3.0);
    vc = m3*sin(wt+4*PI/3.0);
    update_pwm(va,vb,vc);
}

else {
    update_pwm(m1,m2,m3);
}



//// Clear INT flag for this timer
////
     EPwm2Regs.ETCLR.bit.INT = 1;

//
// Acknowledge this interrupt to receive more interrupts from group 3
//
     PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}







