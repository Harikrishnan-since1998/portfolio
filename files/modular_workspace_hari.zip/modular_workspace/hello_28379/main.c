
/*
 * main.c (modular code for PMSM sensorless control)
 *
 * Created on: Nov 3, 2025
 * Author: Dr Arun, Hari
 * IIT Palakkad
 * Electrical Engineering
 */


#include "F28x_Project.h"
#include "math.h"

#include "custom_adc.h"
#include "custom_dac.h"
#include "custom_epwm.h"
#include "custom_epwm2_isr.h"
#include "custom_interrupts_config.h"
#include "custom_sense_adc_values.h"
#include "custom_protection.h"
#include "custom_global_variable.h"
#include "custom_dac_view.h"


//
// Defines
//




//
// Main
//
void main(void)
{
    //
    // ------------------------------------------------------------
    // System Initialization
    // ------------------------------------------------------------
    // Initialize System Control:
    // - Configure PLL
    // - Disable WatchDog
    // - Enable Peripheral Clocks
    // (Function found in F2837xD_SysCtrl.c)
    //
    InitSysCtrl();   // System clock = 200 MHz

    //
    // ------------------------------------------------------------
    // GPIO Initialization
    // ------------------------------------------------------------
    // Set GPIOs to their default state.
    // (Function found in F2837xD_Gpio.c)
    //
    InitGpio();


    //
    // ------------------------------------------------------------
    // PIE and Interrupt Initialization
    // ------------------------------------------------------------
    //
    DINT;   // Disable all CPU interrupts

    //
    // Initialize the PIE control registers to default state:
    // - All PIE interrupts disabled
    // - All interrupt flags cleared
    // (Function found in F2837xD_PieCtrl.c)
    //
    InitPieCtrl();

    //
    // Disable CPU interrupts and clear all flags
    //
    IER = 0x0000;
    IFR = 0x0000;

    //
    // Initialize the PIE vector table with default ISRs.
    // (Populates all entries for debug convenience)
    // (Function found in F2837xD_PieVect.c)
    //
    InitPieVectTable();

    //InitECap1Gpio(26);    // Optional: Configure eCAP1 GPIO if needed

    //
    // ------------------------------------------------------------
    // Peripheral Configuration
    // ------------------------------------------------------------

    //
    // ADC Configuration and Power-Up
    //
    config_ADC();

    //
    // Disable ePWM time-base clock sync before configuration
    //
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    EDIS;

    //
    // ePWM Configuration
    //
    config_EPwm();

    //
    // Re-enable ePWM time-base clock sync after configuration
    //
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;


    //
    // ADC SOC Configuration with ePWM triggering
    //
    config_ADC_SOC_Epwm();



    //
    // DAC Configuration
    //
    config_DAC();        // 12-bit buffered DAC
    config_PWM_DAC();    // PWM-based DAC

    //
    // Interrupt Configuration
    //
    config_interrupts();


    //
    // ------------------------------------------------------------
    // Enable Global Interrupts
    // ------------------------------------------------------------
    //
    EINT;   // Enable Global Interrupt (INTM)
    ERTM;   // Enable Global Real-Time Interrupt (DBGM)


    //
    // ------------------------------------------------------------
    // Main Application Loop
    // ------------------------------------------------------------
    //
    for(;;)
    {
        // protection over current
            protection();

            dac_view();


    }
}












